/* ==========================================================================
   VAK Marketing — поведение страницы.
   Ничего лишнего: шапка, меню, появление блоков, счётчики, гармошка
   аудиторий, панель услуг, лента кейсов, форма.
   ========================================================================== */
(function () {
'use strict';

/* Сюда вписывается адрес, который принимает POST с JSON.
   Пока строка пустая, форма работает в демо-режиме. */
var FORM_ENDPOINT = '';

/* Когда появятся отдельные страницы услуг (/strategy, /linkedin и т.д.),
   переключить на true: кнопка «Подробнее» начнёт вести на них.
   Пока false, чтобы не отправлять посетителя на несуществующий адрес. */
var SERVICE_PAGES = false;

var reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
var $  = function (s, c) { return (c || document).querySelector(s); };
var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

/* ── тост ───────────────────────────────────────────────────────────── */
var toastEl = $('#toast'), toastT;
function toast(msg) {
  if (!toastEl) return;
  toastEl.textContent = msg;
  toastEl.classList.add('is-on');
  clearTimeout(toastT);
  toastT = setTimeout(function () { toastEl.classList.remove('is-on'); }, 2600);
}
document.addEventListener('click', function (e) {
  var a = e.target.closest('[data-soon]');
  if (!a) return;
  e.preventDefault();
  var own = a.getAttribute('data-soon');
  toast(own || (window.__lang === 'en' ? 'This section is coming soon' : 'Раздел скоро появится'));
});

/* ── шапка и мобильное меню ─────────────────────────────────────────── */
var nav = $('#nav'), burger = $('#burger'), menu = $('#menu');
function onScroll() { nav.classList.toggle('is-stuck', scrollY > 18); }
addEventListener('scroll', onScroll, { passive: true });
onScroll();

function closeMenu() {
  if (!menu || menu.hidden) return;
  menu.hidden = true;
  burger.setAttribute('aria-expanded', 'false');
  document.body.classList.remove('is-locked');
  nav.classList.remove('is-open');
}
if (burger) burger.addEventListener('click', function () {
  var open = menu.hidden;
  menu.hidden = !open;
  burger.setAttribute('aria-expanded', String(open));
  document.body.classList.toggle('is-locked', open);
  nav.classList.toggle('is-open', open);
});
if (menu) menu.addEventListener('click', function (e) { if (e.target.closest('a')) closeMenu(); });
addEventListener('keydown', function (e) { if (e.key === 'Escape') closeMenu(); });

/* ── появление блоков ───────────────────────────────────────────────── */
var reveal = $$('[data-reveal]');
if (reduced || !('IntersectionObserver' in window)) {
  reveal.forEach(function (el) { el.classList.add('in'); });
} else {
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (!en.isIntersecting) return;
      en.target.classList.add('in');
      io.unobserve(en.target);
      if (en.target.querySelector('[data-count]') || en.target.hasAttribute('data-count')) countIn(en.target);
    });
  }, { rootMargin: '0px 0px -12% 0px', threshold: 0.08 });
  reveal.forEach(function (el) { io.observe(el); });
}

/* ── счётчики ───────────────────────────────────────────────────────── */
function countIn(root) {
  var nodes = root.hasAttribute('data-count') ? [root] : $$('[data-count]', root);
  nodes.forEach(function (n) {
    if (n.__done) return;
    n.__done = true;
    var to = parseFloat(n.getAttribute('data-count')) || 0;
    var suf = n.getAttribute('data-suffix') || '';
    if (reduced) { n.textContent = fmt(to) + suf; return; }
    var t0 = performance.now(), dur = 1150;
    (function step(t) {
      var p = Math.min(1, (t - t0) / dur);
      var e = 1 - Math.pow(1 - p, 3);
      n.textContent = fmt(Math.round(to * e)) + suf;
      if (p < 1) requestAnimationFrame(step);
    })(t0);
  });
}
function fmt(v) { return String(v).replace(/\B(?=(\d{3})+(?!\d))/g, ' '); }

/* ── гармошка «с кем работаем» ──────────────────────────────────────── */
var slats = $$('.slat');
function openSlat(el) {
  slats.forEach(function (s) { s.classList.toggle('is-open', s === el); });
}
slats.forEach(function (s) {
  s.addEventListener('pointerenter', function (e) { if (e.pointerType === 'mouse') openSlat(s); });
  s.addEventListener('click', function () { openSlat(s); });
  s.addEventListener('focus', function () { openSlat(s); });
});

/* ── услуги ─────────────────────────────────────────────────────────── */
var SRV = [
  { i: '01', href: '/strategy',
    t: 'Стратегия и комплексное ведение проекта',
    d: 'Разрабатываем маркетинговую стратегию и берём на себя сопровождение проекта: позиционирование, PR, контент, LinkedIn, SEO, лидогенерацию, аналитику и отчётность.',
    m: '<path d="M6 14 L30 32"/><path d="M6 32 H30"/><path d="M6 50 L30 32"/><circle cx="32" cy="32" r="3.4"/><path d="M36 32 H58"/><path d="M52 26 L58 32 L52 38"/>' },
  { i: '02', href: '/linkedin',
    t: 'B2B-маркетинг и продвижение в LinkedIn',
    d: 'Помогаем компаниям, фаундерам и sales-командам превращать LinkedIn в канал доверия, экспертности, B2B-диалогов и лидогенерации.',
    m: '<circle cx="13" cy="45" r="4"/><circle cx="30" cy="16" r="4"/><circle cx="51" cy="38" r="4"/><circle cx="35" cy="54" r="4"/><path d="M16 42 L27 20"/><path d="M33 18 L48 35"/><path d="M48 41 L38 51"/><path d="M17 46 L31 53"/>' },
  { i: '03', href: '/pr',
    t: 'PR, СМИ и SERP',
    d: 'Размещаем статьи, пресс-релизы, интервью и экспертные материалы в Tier-1 и Tier-2-3 медиа, усиливаем репутацию бренда в поисковой выдаче.',
    m: '<path d="M8 17 H56"/><path d="M8 29 H41"/><path d="M8 41 H49"/><path d="M8 53 H33"/><circle cx="51" cy="53" r="6.5"/><path d="M56 58 L60 62"/>' },
  { i: '04', href: '/seo',
    t: 'AI SEO и автоматизация маркетинга',
    d: 'Работаем с SEO-структурой, ключевыми запросами, контентом, аналитикой и автоматизацией маркетинговых процессов.',
    m: '<circle cx="32" cy="32" r="20"/><path d="M32 12 V22"/><path d="M32 42 V52"/><path d="M12 32 H22"/><path d="M42 32 H52"/><path d="M25 39 L32 25 L39 39"/><path d="M28 35 H36"/>' },
  { i: '05', href: '/course',
    t: 'B2B и B2C курс по LinkedIn',
    d: 'Создаём образовательные продукты для компаний, sales-команд, фаундеров, экспертов и предпринимателей, включая курс по LinkedIn-продвижению.',
    m: '<path d="M8 20 L32 10 L56 20 L32 30 Z"/><path d="M18 25 V42 C18 42 24 48 32 48 C40 48 46 42 46 42 V25"/><path d="M56 20 V38"/>' },
  { i: '06', href: '/localization',
    t: 'Translation & Localization Services',
    d: 'Адаптируем сайты, презентации, статьи, пресс-релизы, whitepapers, pitch decks и любые документы под международные рынки.',
    m: '<circle cx="26" cy="26" r="18"/><path d="M8 26 H44"/><path d="M26 8 C34 16 34 36 26 44 C18 36 18 16 26 8"/><path d="M36 40 H58 V58 H36 Z"/><path d="M41 49 H53"/>' }
];

var srvSec = $('#services'), srvPin = $('#srvPin'), srvDeck = $('#srvDeck');
var srvCards = [], srvActive = -1;

/* Карточки строятся из SRV: содержимое и значки уже лежат там, а перевод
   берётся из того же словаря, что и раньше. */
function buildSrvCards() {
  if (!srvDeck) return;
  srvDeck.innerHTML = '';
  srvCards = SRV.map(function (s, n) {
    var el = document.createElement('article');
    el.className = 'card srv__card';
    /* Содержимое лежит в отдельной обёртке: в колоде у неё своя прозрачность,
       поэтому за активной карточкой видны сами карточки, а не их тексты. */
    el.innerHTML = '<div class="srv__body">' +
      '<svg class="srv__mark" viewBox="0 0 64 64" aria-hidden="true">' + s.m + '</svg>' +
      '<h3 class="srv__t"></h3><p class="srv__d"></p>' +
      '<a class="link-arrow" href="#contact"></a></div>';
    srvDeck.appendChild(el);
    fillSrvCard(el, n);
    return el;
  });
}

function fillSrvCard(el, n) {
  var s = SRV[n], d = window.__dict;
  el.querySelector('.srv__t').innerHTML = (d && d['srv.t' + (n + 1)]) || s.t;
  el.querySelector('.srv__d').innerHTML = (d && d['srv.d' + (n + 1)]) || s.d;
  var a = el.querySelector('.link-arrow');
  // в словаре значение уже со стрелкой: 'Read more<i></i>'
  a.innerHTML = (d && d['srv.more']) || 'Подробнее<i></i>';
  if (SERVICE_PAGES) { a.setAttribute('href', s.href); a.removeAttribute('data-soon'); }
  else {
    a.setAttribute('href', '#contact');
    a.setAttribute('data-soon', window.__lang === 'en'
      ? 'The service page is coming soon' : 'Страница услуги скоро появится');
  }
}

/* Подсветка активной строки в списке-оглавлении и доступность колоды:
   неактивные карточки убираются из обхода с клавиатуры и от скринридера,
   иначе Tab уводит в невидимое. */
function setSrv(n) {
  if (n === srvActive) return;
  srvActive = n;
  $$('.srv__row').forEach(function (r) {
    r.classList.toggle('is-on', +r.getAttribute('data-srv') === n);
  });
  srvCards.forEach(function (c, i) {
    var on = i === n;
    c.classList.toggle('is-on', on);
    if (srvDeck.parentElement && srvSec.classList.contains('is-deck')) {
      c.setAttribute('aria-hidden', on ? 'false' : 'true');
      c.querySelector('.link-arrow').tabIndex = on ? 0 : -1;
    }
  });
}

buildSrvCards();
window.__setSrv = function () {
  srvCards.forEach(function (el, n) { fillSrvCard(el, n); });
  var n = srvActive; srvActive = -1; setSrv(n < 0 ? 0 : n);
};
setSrv(0);

/* ── колода услуг: закреплённая секция ──────────────────────────────────
   Секции задаётся прокручиваемая длина в STEP пикселей на карточку, а сцена
   внутри липкая: пока эта длина идёт, колода стоит на экране. Доля прокрутки
   внутри неё и есть номер карточки, дробный — поэтому движение непрерывное,
   а не переключение по щелчку. Уходящая карточка вылетает на зрителя
   и заваливается назад, следующая поднимается из стопки. */
if (srvSec && srvPin && srvDeck && srvCards.length && !reduced) (function () {
  var N = srvCards.length, STEP = 600, pinTop = 0, raf = 0;

  /* На широком экране колода стоит по центру и получает две вещи, которых
     нет на телефоне: расфокус по глубине и наклон верхней карточки под
     курсором. Обе завязаны на mouse-указатель, поэтому на тач-экранах
     не включаются. */
  var wideQ = matchMedia('(min-width: 901px)'), fineQ = matchMedia('(pointer: fine)');
  var wide = wideQ.matches && fineQ.matches;
  var tiltTX = 0, tiltTY = 0, tiltX = 0, tiltY = 0, hoverT = 0, hover = 0;

  function absTop(el) { var y = 0; for (; el; el = el.offsetParent) y += el.offsetTop; return y; }

  function layout() {
    wide = wideQ.matches && fineQ.matches;
    if (!wide) { tiltTX = tiltTY = hoverT = 0; }
    STEP = Math.round(Math.max(420, Math.min(innerHeight * 0.82, 760)));
    srvPin.style.height = ((N - 1) * STEP + innerHeight) + 'px';
    pinTop = absTop(srvPin);
    /* Высота секции только что изменилась, а кадры сцены привязаны к позициям
       секций — пересчёт обязателен, иначе прибор поедет. */
    if (window.__vakRelayout) window.__vakRelayout();
    draw();
  }

  function pos() {
    return Math.max(0, Math.min(N - 1, (scrollY - pinTop) / STEP));
  }

  function draw() {
    raf = 0;
    /* Наклон и подъём догоняют цель, а не прыгают к ней: за счёт этого
       карточка отзывается на курсор мягко и так же мягко возвращается. */
    tiltX += (tiltTX - tiltX) * 0.14;
    tiltY += (tiltTY - tiltY) * 0.14;
    hover += (hoverT - hover) * 0.14;

    var p = pos();
    for (var i = 0; i < N; i++) {
      var c = srvCards[i], d = i - p, z, y, rx, ry, s, op, blur;
      if (d >= 0) {                       // ещё в стопке, уходит вглубь
        z  = -d * 205;
        y  =  d * 34;
        rx = -Math.min(d, 1.8) * 7;
        ry =  0;
        s  =  1 - Math.min(d, 3) * 0.05;
        op = (1 - Math.min(d, 3) * 0.18) * Math.max(0, Math.min(1, 3 - d));
        blur = wide ? Math.min(d, 2) * 2.2 : 0;
      } else {                            // пролистана, вылетает на зрителя
        var a = -d;
        z  =  a * 520;
        y  = -a * 205;
        rx =  a * 22;
        ry = -a * 9;
        s  =  1;
        op =  Math.max(0, 1 - a * 1.5);
        blur = wide ? Math.min(a, 1.3) * 7 : 0;   // уходящая карточка теряет резкость
      }

      /* Наклон под курсором достаётся только верхней карточке: у остальных
         вес нулевой, иначе вся стопка начинает шевелиться. */
      var w = Math.max(0, 1 - Math.abs(d));
      if (wide && w > 0.001) {
        ry += tiltX * 5.5 * w * hover;
        rx += -tiltY * 4.2 * w * hover;
        z  += 26 * w * hover;
      }

      /* Текст гаснет заметно быстрее самой карточки: иначе на перелёте
         две подписи накладываются друг на друга и нечитаемы обе. */
      c.firstChild.style.opacity = Math.max(0, 1 - Math.abs(d) * 2.6).toFixed(3);
      c.style.opacity = op.toFixed(3);
      c.style.transform = 'translate3d(0,' + y.toFixed(1) + 'px,' + z.toFixed(1) + 'px)'
        + ' rotateX(' + rx.toFixed(2) + 'deg) rotateY(' + ry.toFixed(2) + 'deg)'
        + ' scale(' + s.toFixed(3) + ')';

      /* Всё, что не меняется от кадра к кадру, и пишем не каждый кадр:
         каждая такая запись — лишний пересчёт стилей. Заодно невидимая
         карточка отпускает свой слой на видеокарте: шесть слоёв размером
         во всю колоду держать незачем. */
      var zi = 1000 - Math.round(d * 10);
      if (c.__zi !== zi) { c.__zi = zi; c.style.zIndex = String(zi); }
      var live = op >= 0.004;
      if (c.__live !== live) { c.__live = live; c.style.visibility = live ? 'visible' : 'hidden'; }
      var bs = blur > 0.2 ? 'blur(' + blur.toFixed(1) + 'px)' : '';
      if (c.__bs !== bs) { c.__bs = bs; c.style.filter = bs; }
    }
    setSrv(Math.max(0, Math.min(N - 1, Math.round(p))));

    // пока наклон не улёгся, продолжаем считать кадры
    if (Math.abs(tiltTX - tiltX) > 0.002 || Math.abs(tiltTY - tiltY) > 0.002
        || Math.abs(hoverT - hover) > 0.002) kick();
  }

  function kick() { if (!raf) raf = requestAnimationFrame(draw); }
  var snapTimer = 0, wheelLocked = false;
  function snapToService() {
    if (drag) return;
    var raw = (scrollY - pinTop) / STEP;
    /* Вход и выход из секции не перехватываем: посетитель должен свободно
       перейти к соседним блокам. Между ними доводим прокрутку до карточки,
       чтобы нельзя было остановиться между услугами. */
    if (raw <= .04 || raw >= N - 1.04) return;
    goTo(Math.round(raw));
  }
  function onScrollDeck() {
    kick();
    clearTimeout(snapTimer);
    snapTimer = setTimeout(snapToService, 120);
  }

  /* Курсор над колодой: верхняя карточка кренится за ним, по стеклу ходит
     блик. Блик двигаем переменными, а не пересчётом фона. */
  srvDeck.addEventListener('pointermove', function (e) {
    if (!wide || e.pointerType !== 'mouse' || drag) return;
    var r = srvDeck.getBoundingClientRect();
    var nx = (e.clientX - r.left) / r.width, ny = (e.clientY - r.top) / r.height;
    tiltTX = (nx - 0.5) * 2;
    tiltTY = (ny - 0.5) * 2;
    hoverT = 1;
    var on = srvCards[Math.max(0, Math.min(N - 1, Math.round(pos())))];
    if (on) {
      on.style.setProperty('--mx', (nx * 100).toFixed(1) + '%');
      on.style.setProperty('--my', (ny * 100).toFixed(1) + '%');
    }
    kick();
  });
  srvDeck.addEventListener('pointerleave', function () {
    tiltTX = tiltTY = hoverT = 0;
    kick();
  });

  function goTo(n, smooth) {
    window.scrollTo({ top: pinTop + Math.max(0, Math.min(N - 1, n)) * STEP,
                      behavior: smooth === false ? 'auto' : 'smooth' });
  }

  /* На десктопе колесо/трекпад переводит сразу к следующей услуге. Так
     карточки не проскальзывают на половину экрана и нельзя промотать две
     услуги одним быстрым жестом. */
  srvSec.addEventListener('wheel', function (e) {
    if (!wide || e.deltaY === 0) return;
    var raw = (scrollY - pinTop) / STEP;
    if (raw < -.04 || raw > N - 1 + .04) return;
    var current = Math.round(raw);
    var next = current + (e.deltaY > 0 ? 1 : -1);
    if (next < 0 || next >= N) return;
    e.preventDefault();
    if (wheelLocked) return;
    wheelLocked = true;
    goTo(next);
    setTimeout(function () { wheelLocked = false; }, 280);
  }, { passive: false });

  /* Перетаскивание. Оно не двигает колоду напрямую, а прокручивает страницу:
     иначе появился бы второй источник правды и после отпускания картинка
     прыгала бы к тому, что говорит прокрутка. На тач-экране тянем по
     горизонтали (touch-action: pan-y оставляет вертикаль странице), мышью —
     по вертикали, как привычнее. */
  var drag = null, DRAG_STEP = 210;
  srvDeck.addEventListener('pointerdown', function (e) {
    if (e.button) return;
    drag = { x: e.clientX, y: e.clientY, top: scrollY, touch: e.pointerType !== 'mouse', moved: false };
    srvDeck.setPointerCapture(e.pointerId);
    srvDeck.classList.add('is-drag');
  });
  srvDeck.addEventListener('pointermove', function (e) {
    if (!drag) return;
    var delta = drag.touch ? drag.x - e.clientX : drag.y - e.clientY;
    if (Math.abs(delta) > 3) drag.moved = true;
    window.scrollTo({ top: drag.top + delta * (STEP / DRAG_STEP), behavior: 'auto' });
  });
  function endDrag(e) {
    if (!drag) return;
    var moved = drag.moved;
    drag = null;
    srvDeck.classList.remove('is-drag');
    if (srvDeck.hasPointerCapture && e && srvDeck.hasPointerCapture(e.pointerId))
      srvDeck.releasePointerCapture(e.pointerId);
    if (moved) goTo(Math.round(pos()));      // после броска довести до карточки
  }
  srvDeck.addEventListener('pointerup', endDrag);
  srvDeck.addEventListener('pointercancel', endDrag);
  srvDeck.addEventListener('dragstart', function (e) { e.preventDefault(); });

  /* Список справа работает оглавлением: клик и фокус ведут к своей карточке.
     Наведение больше ничего не переключает — при закреплённой секции это
     означало бы прокрутку страницы под курсором. */
  $$('.srv__row').forEach(function (r) {
    var n = +r.getAttribute('data-srv');
    r.addEventListener('click', function () { goTo(n); });
    r.addEventListener('focus', function () { if (Math.round(pos()) !== n) goTo(n); });
  });
  document.addEventListener('click', function (e) {
    var link = e.target.closest('a[href="#services"]');
    if (!link) return;
    e.preventDefault();
    goTo(0);
  });
  srvSec.addEventListener('keydown', function (e) {
    var n = Math.round(pos());
    if (e.key === 'ArrowDown' || e.key === 'ArrowRight') { e.preventDefault(); goTo(n + 1); }
    else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') { e.preventDefault(); goTo(n - 1); }
  });

  srvSec.classList.add('is-deck');
  addEventListener('scroll', onScrollDeck, { passive: true });
  addEventListener('resize', layout);
  layout();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(layout);
})();

/* ── лента кейсов ───────────────────────────────────────────────────── */
var rail = $('#rail'), railBar = $('#railBar'),
    railPrev = $('#railPrev'), railNext = $('#railNext');
if (rail) {
  var step = function () {
    var c = rail.querySelector('.case');
    return c ? c.getBoundingClientRect().width + 18 : 380;
  };
  var syncRail = function () {
    var max = rail.scrollWidth - rail.clientWidth;
    var frac = rail.clientWidth / rail.scrollWidth;
    railBar.style.width = (frac * 100) + '%';
    railBar.style.transform = 'translateX(' + (max > 0 ? (rail.scrollLeft / max) * (100 / frac - 100) : 0) + '%)';
    railPrev.disabled = rail.scrollLeft < 6;
    railNext.disabled = rail.scrollLeft > max - 6;
  };
  rail.addEventListener('scroll', syncRail, { passive: true });
  addEventListener('resize', syncRail);
  railPrev.addEventListener('click', function () { rail.scrollBy({ left: -step(), behavior: 'smooth' }); });
  railNext.addEventListener('click', function () { rail.scrollBy({ left:  step(), behavior: 'smooth' }); });
  syncRail();
}

/* ── клиенты: кольцо шкалы ──────────────────────────────────────────────
   Лента не «бежит» с постоянной скоростью, а проворачивается: скорость
   складывается из медленного дрейфа в покое и прокрутки страницы — вниз
   вперёд, вверх назад, как реагирует и сам прибор. Резкость имени считается
   от расстояния до фокальной плоскости, поэтому края полосы гасит расфокус,
   а не градиент. При наведении плоскость переезжает под курсор и лента почти
   замирает: наводку на резкость делает сам посетитель. */
var ringEl = $('#ring'), ringSet = $('#ringSet');
if (ringEl && ringSet && !reduced) (function () {
  var PAD = 64;          // запас за краями, чтобы имя уезжало целиком
  var DRIFT = 25;        // px/с в покое
  var GAIN = 0.40;       // вклад скорости прокрутки
  var VMAX = 620;        // потолок, выше лента мажет
  var SLOW = 0.13;       // во сколько раз лента медленнее под курсором

  var src = $$('.ring__i', ringSet);
  if (!src.length) return;

  var items = [], W = 0, setW = 0, L = 0, maxW = 0, half0 = 0, blurMax = 4.6;
  var offset = 0, v = DRIFT, hov = 0, hovT = 0, foc = .5, focT = .5;
  var lastY = scrollY, sv = 0, prevT = 0, onScreen = true, built = false;

  function build() {
    /* Мерить ширины нужно в обычной раскладке: в рабочем состоянии имена
       расставлены абсолютно и естественной ширины у строки уже нет.
       Промежуточное состояние не успевает отрисоваться — класс снимается
       и возвращается в пределах одной задачи. */
    ringEl.classList.remove('is-live');
    items.forEach(function (it) { if (it.clone) it.el.remove(); });
    items = [];

    W = ringEl.clientWidth;
    if (!W) return;

    var g = Math.max(26, Math.min(72, W * 0.042));
    var gaps = [], h = 0;
    setW = 0; maxW = 0;

    src.forEach(function (el) {
      var w = el.offsetWidth;
      var gp = g * (parseFloat(getComputedStyle(el).getPropertyValue('--g')) || 1);
      gaps.push(gp);
      setW += w + gp;
      if (w > maxW) maxW = w;
      if (el.offsetHeight > h) h = el.offsetHeight;
    });
    if (setW <= 0) return;

    /* Копий ровно столько, чтобы длина кольца перекрыла полосу вместе
       с запасом: тогда имя перескакивает в хвост, уже полностью уехав
       за левый край, и шва не видно. */
    var N = Math.max(1, Math.min(8, Math.ceil((W + maxW + 2 * PAD) / setW)));
    L = setW * N;

    /* Зона резкости не может быть уже самого длинного имени: на узкой полосе
       W*0.30 меньше, чем «Ethereum Foundation», и тогда ни одно имя не успевает
       стать чётким целиком — лента читается размытым обрезком. Там же приглушено
       и само размытие: при мелком кегле 4.6 px съедают букву целиком. */
    half0 = Math.max(W * 0.30, maxW * 0.62);
    blurMax = W < 620 ? 2.6 : 4.6;

    for (var c = 0; c < N; c++) {
      var at = c * setW;
      for (var i = 0; i < src.length; i++) {
        var el = src[i];
        if (c > 0) {
          el = src[i].cloneNode(true);
          el.setAttribute('aria-hidden', 'true');   // копии не для чтения с экрана
          el.removeAttribute('data-i18n');
          ringSet.appendChild(el);
        }
        el.style.setProperty('--gh', (gaps[i] / 2) + 'px');
        items.push({ el: el, w: src[i].offsetWidth, base: at, clone: c > 0, b: -1, s: -1, vis: -1 });
        at += src[i].offsetWidth + gaps[i];
      }
    }

    ringEl.style.setProperty('--ring-h', Math.round(h + 34) + 'px');
    ringEl.classList.add('is-live');
    built = true;
    draw(0);
  }

  function draw(dt) {
    /* Прыжок по якорной ссылке — это не скорость прокрутки, а телепорт:
       без отсечки он даёт мгновенный рывок ленты до потолка. */
    var y = scrollY, dy = y - lastY;
    lastY = y;
    if (Math.abs(dy) > innerHeight * 1.2) dy = 0;
    if (dt) sv += (dy / Math.max(dt, 1e-4) - sv) * Math.min(1, dt * 7);

    var vT = Math.max(-VMAX, Math.min(VMAX, DRIFT + sv * GAIN));
    v   += (vT   - v)   * (1 - Math.pow(1 - .11, dt * 60));
    hov += (hovT - hov) * (1 - Math.pow(1 - .12, dt * 60));
    foc += (focT - foc) * (1 - Math.pow(1 - .14, dt * 60));

    offset += v * (1 - hov * (1 - SLOW)) * dt;

    var fx = W * (.5 + (foc - .5) * hov);      // фокальная плоскость
    var half = half0 * (1 - .30 * hov);        // под курсором зона резкости уже

    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var x = it.base - offset;
      x = ((x % L) + L) % L;
      if (x > W + PAD) x -= L;

      if (x < -it.w - PAD) {                    // припарковано за кадром
        if (it.vis !== 0) { it.el.style.opacity = '0'; it.vis = 0; }
        continue;
      }

      var d = (x + it.w / 2 - fx) / half;
      var f = Math.exp(-d * d * 1.35);

      it.el.style.transform = 'translate3d(' + x.toFixed(1) + 'px,-50%,0) translateY('
        + ((1 - f) * 3.2).toFixed(2) + 'px) scale(' + (.972 + .028 * f).toFixed(3) + ')';
      it.el.style.opacity = (.20 + .80 * f).toFixed(3);
      it.el.style.color = 'rgb(' + (166 + 89 * f | 0) + ',' + (160 + 95 * f | 0)
        + ',' + (194 + 61 * f | 0) + ')';
      it.vis = 1;

      /* Размытие и свечение переписываются только при заметном изменении:
         это самые дорогие свойства, и гнать их каждый кадр незачем. */
      var b = Math.round((1 - f) * blurMax / .3) * .3;
      if (b !== it.b) { it.el.style.filter = b > .05 ? 'blur(' + b.toFixed(1) + 'px)' : 'none'; it.b = b; }
      var s = f > .45 ? Math.round(f * 10) / 10 : 0;
      if (s !== it.s) {
        it.el.style.textShadow = s ? '0 0 42px rgba(180,150,255,' + (.5 * s * s).toFixed(2) + ')' : 'none';
        it.s = s;
      }
    }
  }

  function frame(t) {
    requestAnimationFrame(frame);
    if (!built || document.hidden || !onScreen) { prevT = t; return; }
    var dt = prevT ? Math.min(.05, (t - prevT) / 1000) : .016;
    prevT = t;
    draw(dt);
  }

  ringEl.addEventListener('pointermove', function (e) {
    if (e.pointerType !== 'mouse') return;
    var r = ringEl.getBoundingClientRect();
    focT = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    hovT = 1;
  });
  ringEl.addEventListener('pointerleave', function () { hovT = 0; });

  if ('IntersectionObserver' in window) {
    new IntersectionObserver(function (en) { onScreen = en[0].isIntersecting; },
      { rootMargin: '120px 0px' }).observe(ringEl);
  }

  var rt;
  addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(build, 180); });

  build();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(build);
  window.__ringSync = build;    // пересборка после смены языка: имена меняют ширину
  requestAnimationFrame(frame);
})();

/* ── форма ──────────────────────────────────────────────────────────── */
var form = $('#lead'), note = $('#formNote');
function say(kind, ru, en) {
  note.className = 'form__note ' + kind;
  note.textContent = window.__lang === 'en' ? en : ru;
}
if (form) form.addEventListener('submit', function (e) {
  e.preventDefault();
  var d = new FormData(form);
  if (d.get('website_url')) return;                       // ловушка для ботов

  var bad = null;
  ['name', 'contact'].forEach(function (k) {
    var el = form.elements[k];
    var ok = String(d.get(k) || '').trim().length > 1;
    el.setAttribute('aria-invalid', ok ? 'false' : 'true');
    if (!ok && !bad) bad = el;
  });
  if (bad) {
    bad.focus();
    say('is-err', 'Заполните имя и контакт для связи.', 'Please add your name and a contact.');
    return;
  }

  var payload = {
    name: d.get('name'), company: d.get('company'), site: d.get('site'),
    contact: d.get('contact'), service: d.get('service'),
    page: location.href, lang: window.__lang || 'ru'
  };

  var btn = form.querySelector('button[type=submit]');
  btn.disabled = true;
  say('', 'Отправляем…', 'Sending…');

  if (!FORM_ENDPOINT) {
    window.__lastLead = payload;
    console.log('[VAK] демо-режим, заявка не отправлена:', payload);
    setTimeout(function () {
      btn.disabled = false;
      form.reset();
      say('is-ok', 'Заявка принята (демо-режим: адрес приёма ещё не подключён).',
                   'Received (demo mode: the endpoint is not connected yet).');
    }, 550);
    return;
  }

  fetch(FORM_ENDPOINT, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
  }).then(function (r) {
    if (!r.ok) throw new Error(r.status);
    form.reset();
    say('is-ok', 'Спасибо, заявка отправлена. Ответим в течение рабочего дня.',
                 'Thanks, your request is on its way. We reply within one business day.');
  }).catch(function () {
    say('is-err', 'Не получилось отправить. Напишите нам в Telegram или на почту.',
                  'Sending failed. Please reach us on Telegram or by email.');
  }).then(function () { btn.disabled = false; });
});

/* ── мелочи ─────────────────────────────────────────────────────────── */
var yr = $('#yr'); if (yr) yr.textContent = new Date().getFullYear();

})();
