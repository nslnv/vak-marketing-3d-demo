/* ==========================================================================
   VAK Marketing — сцена на WebGL.

   Образ страницы: оптический прибор. Слева в кадр входит рассеянный шум
   рынка, проходит через блок линз и выходит собранным пучком — это ровно
   то, что агентство делает с коммуникацией проекта.

   Всё считается на GPU: три стеклянные линзы с настоящим преломлением по
   процедурной кубической карте (с дисперсией по каналам), поток частиц,
   который живёт в вершинном шейдере, и звёзды. Ни одной внешней текстуры.
   ========================================================================== */

import * as THREE from '../vendor/three.module.min.js';

const canvas = document.getElementById('stage');
if (canvas) boot(canvas);

function boot(canvas) {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const coarse  = matchMedia('(pointer: coarse)').matches;

  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({
      canvas, alpha: true, antialias: !coarse, powerPreference: 'high-performance'
    });
  } catch (e) { return; }                       // нет WebGL — остаётся CSS-фон

  renderer.setClearAlpha(0);
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;

  /* Потолок плотности пикселей. Ниже он ещё и подстраивается на ходу:
     сцена сама снижает разрешение, если кадры перестают укладываться
     в бюджет, и возвращает его обратно, когда запас появляется. */
  const DPR_MAX = coarse ? 1.4 : 1.6;
  const DPR_MIN = 1.0;
  let dprCap = DPR_MAX;
  const scene  = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(34, 1, 0.1, 120);
  camera.position.set(0, 0, 7.2);

  /* ─────────── 1. процедурная кубическая карта окружения ───────────
     Она задаёт весь характер стекла: тёплый пурпурный ключ справа,
     холодный циан слева, мягкий фиолетовый верх и одна яркая точка. */
  const envRT = new THREE.WebGLCubeRenderTarget(256);
  envRT.texture.generateMipmaps = false;
  envRT.texture.minFilter = THREE.LinearFilter;
  {
    const envScene = new THREE.Scene();
    envScene.add(new THREE.Mesh(
      new THREE.SphereGeometry(50, 32, 24),
      new THREE.ShaderMaterial({
        side: THREE.BackSide,
        toneMapped: false,
        vertexShader: `
          varying vec3 vDir;
          void main(){ vDir = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
        fragmentShader: `
          varying vec3 vDir;
          float lobe(vec3 d, vec3 l, float p){ return pow(max(dot(d, normalize(l)), 0.0), p); }
          void main(){
            vec3 d = normalize(vDir);
            vec3 c = vec3(0.008, 0.007, 0.022);
            c += vec3(0.045, 0.028, 0.115) * smoothstep(-0.75, 1.0, d.y);
            c += vec3(1.00, 0.30, 0.66) * lobe(d, vec3( 0.62, 0.38, -0.70),  5.0) * 0.62;
            c += vec3(0.34, 0.82, 1.00) * lobe(d, vec3(-0.78, 0.12,  0.60),  6.0) * 1.30;
            c += vec3(0.62, 0.58, 1.00) * lobe(d, vec3( 0.05, 1.00,  0.12),  2.2) * 0.72;
            c += vec3(1.00, 0.94, 1.00) * lobe(d, vec3( 0.34, 0.62,  0.70), 90.0) * 3.20;
            c += vec3(0.90, 0.70, 1.00) * lobe(d, vec3(-0.30,-0.85,  0.42), 40.0) * 0.55;
            // софтбоксы: узкие яркие полосы, они и лепят форму стекла
            float b1 = smoothstep(0.11, 0.0, abs(d.y - 0.42)) * smoothstep(1.0, 0.15, abs(d.x + 0.25));
            c += vec3(1.00, 0.98, 1.00) * b1 * 2.60;
            float b2 = smoothstep(0.07, 0.0, abs(d.x - 0.62)) * smoothstep(1.0, 0.10, abs(d.y - 0.10));
            c += vec3(0.80, 0.90, 1.00) * b2 * 1.85;
            float b3 = smoothstep(0.05, 0.0, abs(d.y + 0.50)) * smoothstep(1.0, 0.20, abs(d.z - 0.30));
            c += vec3(1.00, 0.55, 0.85) * b3 * 1.25;
            gl_FragColor = vec4(c, 1.0);
          }`
      })
    ));
    new THREE.CubeCamera(0.1, 100, envRT).update(renderer, envScene);
  }
  const ENV = envRT.texture;

  /* ─────────── 2. объектив ───────────
     Собран как настоящий прибор: задний фланец, три стеклянных элемента
     в оправах, девятилепестковая диафрагма, накатное кольцо, рёбра корпуса
     и передний безель. Диафрагма живая: лепестки поворачиваются вокруг
     своих осей и меняют просвет. */
  const rig = new THREE.Group();       // общий наклон и парение
  const optic = new THREE.Group();     // сам объектив
  rig.add(optic);
  scene.add(rig);

  const V2 = THREE.Vector2;

  /* профиль двояковыпуклой линзы с фаской по кромке: фаска ловит свет
     и даёт ту самую тонкую яркую окантовку */
  function lensProfile(R, curve, edge) {
    const p = [], N = 40, ch = 0.020, Rc = R - ch;
    const sag = r => curve * Math.sqrt(Math.max(0, 1 - (r / R) ** 2));
    for (let i = 0; i <= N; i++) { const r = (i / N) * Rc; p.push(new V2(r, edge * 0.5 + sag(r))); }
    p.push(new V2(R, edge * 0.5 - ch * 0.6));
    p.push(new V2(R, -edge * 0.5 + ch * 0.6));
    for (let i = N; i >= 0; i--) { const r = (i / N) * Rc; p.push(new V2(r, -edge * 0.5 - sag(r))); }
    return p;
  }

  /* точёное кольцо: профиль с фасками, лату́нный вид даёт сам шейдер */
  function ringProfile(ri, ro, h) {
    const c = Math.min(0.045, h * 0.4);
    return [
      new V2(ri, 0), new V2(ri, h - c), new V2(ri + c, h),
      new V2(ro - c, h), new V2(ro, h - c),
      new V2(ro, c), new V2(ro - c, 0),
      new V2(ri + c, 0), new V2(ri, 0)
    ];
  }

  /* обечайка корпуса: труба со стенкой и фасками по торцам.
     Ступенчатые диаметры этих обечаек и делают силуэт прибора. */
  function shellProfile(ri, ro, z0, z1, ch) {
    ch = ch || 0.05;
    return [
      new V2(ri, z0), new V2(ro - ch, z0), new V2(ro, z0 + ch),
      new V2(ro, z1 - ch), new V2(ro - ch, z1), new V2(ri, z1), new V2(ri, z0)
    ];
  }

  const baseVert = `
    varying vec3 vN; varying vec3 vW; varying vec3 vP; varying vec3 vT;
    void main(){
      vec4 wp = modelMatrix * vec4(position, 1.0);
      vW = wp.xyz; vP = position;
      vN = normalize(mat3(modelMatrix) * normal);
      // касательная вдоль окружности вокруг оси Y — нужна насечке на кольце
      vec3 tr = vec3(-position.z, 0.0, position.x);
      vT = normalize(mat3(modelMatrix) * (dot(tr, tr) > 1e-8 ? tr : vec3(1.0, 0.0, 0.0)));
      gl_Position = projectionMatrix * viewMatrix * wp;
    }`;

  const glassFrag = `
    uniform samplerCube uEnv;
    uniform vec3  uTint, uEdge, uAbs;
    uniform float uIor, uDisp, uAlpha, uGain, uCoat;
    varying vec3 vN; varying vec3 vW; varying vec3 vP; varying vec3 vT;
    void main(){
      vec3 N = normalize(vN);
      vec3 V = normalize(vW - cameraPosition);
      float ndv  = clamp(dot(N, -V), 0.0, 1.0);
      float fres = 0.04 + 0.96 * pow(1.0 - ndv, 4.4);

      float e = 1.0 / uIor;
      vec3 tr = vec3(
        textureCube(uEnv, refract(V, N, e - uDisp)).r,
        textureCube(uEnv, refract(V, N, e        )).g,
        textureCube(uEnv, refract(V, N, e + uDisp)).b
      );
      vec3 refl = textureCube(uEnv, reflect(V, N)).rgb;

      /* Просветляющее покрытие. У каждого элемента свой состав, и его цвет
         гуляет с углом: у настоящей оптики отблеск на просвете зелёный,
         лиловый или янтарный в зависимости от того, как смотришь. */
      vec3 coat = 0.5 + 0.5 * cos(6.2831853 *
                  (vec3(0.00, 0.33, 0.67) + (1.0 - ndv) * 1.15 + uCoat));
      refl *= mix(vec3(1.0), coat, 0.60);

      // выпуклая линза толще к центру: там стекло сильнее красит проходящий свет
      vec3 absorb = exp(-uAbs * pow(ndv, 0.7) * 1.7);
      vec3 col = mix(tr * uTint * absorb, refl, fres) * uGain;

      // вторичный блик от задней поверхности: слабый, но он и даёт «мокрое» стекло
      col += textureCube(uEnv, reflect(V, normalize(N + V * 0.32))).rgb
             * uTint * fres * 0.22;

      // острый блик от главного софтбокса
      float sp = pow(max(dot(reflect(V, N), normalize(vec3(-0.25, 0.78, 0.60))), 0.0), 240.0);
      col += vec3(1.0, 0.97, 1.0) * sp * 3.0;
      col += uEdge * pow(1.0 - ndv, 6.0) * 1.55;

      float a = uAlpha * clamp(0.32 + 0.80 * fres + 0.26 * length(col), 0.0, 1.0);
      gl_FragColor = vec4(col, a);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }`;

  const glassUniforms = [];
  function glass(o) {
    const u = {
      uEnv:  { value: ENV },
      uTint: { value: new THREE.Color(o.tint) },
      uEdge: { value: new THREE.Color(o.edge) },
      uAbs:  { value: new THREE.Vector3(o.abs[0], o.abs[1], o.abs[2]) },
      uIor:  { value: o.ior },
      uDisp: { value: o.disp },
      uCoat: { value: o.coat || 0 },
      uAlpha:{ value: 1 },
      uGain: { value: 1 }
    };
    glassUniforms.push(u);
    return new THREE.ShaderMaterial({
      uniforms: u, vertexShader: baseVert, fragmentShader: glassFrag,
      transparent: true, depthWrite: false, side: THREE.FrontSide
    });
  }

  /* металл: отражение окружения плюс насечка. Насечка честная — она
     возмущает нормаль по касательной, поэтому блики по ней бегут. */
  const metalFrag = `
    uniform samplerCube uEnv;
    uniform vec3 uBase, uSpec;
    uniform float uAlpha, uKnurl, uRough, uTicks;
    varying vec3 vN; varying vec3 vW; varying vec3 vP; varying vec3 vT;
    void main(){
      vec3 N = normalize(vN);
      if (!gl_FrontFacing) N = -N;              // изнутри тубуса грани смотрят на нас
      float groove = 1.0;
      float ang = atan(vP.z, vP.x);
      if (uKnurl > 0.5) {
        float g = sin(ang * uKnurl);
        N = normalize(N + vT * g * 1.25);
        groove = 0.38 + 0.62 * abs(g);
      } else {
        // микрошлифовка по окружности: даёт точёному металлу живой отблеск
        float br = sin(ang * 84.0) * 0.6 + sin(ang * 137.0) * 0.4;
        N = normalize(N + vT * br * 0.035);
        groove = 0.94 + 0.06 * br;
      }
      // гравированная шкала: узкие штрихи, каждый пятый ярче
      float tick = 0.0;
      if (uTicks > 0.5) {
        float idx = ang / 6.2831853 * uTicks;
        float f = abs(fract(idx) - 0.5) * 2.0;
        float major = smoothstep(0.72, 0.88, abs(fract(idx / 5.0) - 0.5) * 2.0);
        tick = smoothstep(0.84, 0.97, f) * (0.55 + 0.85 * major);
      }

      vec3 V = normalize(vW - cameraPosition);
      float ndv = clamp(dot(N, -V), 0.0, 1.0);
      vec3 R = reflect(V, N);
      vec3 refl = textureCube(uEnv, R).rgb;

      vec3 col = mix(uBase, refl * 1.25, (0.42 + 0.5 * pow(1.0 - ndv, 2.2)) * (1.0 - uRough * 0.45));
      col += uSpec * pow(max(dot(R, normalize(vec3(-0.25, 0.78, 0.60))), 0.0), 60.0) * 2.4;
      col += uSpec * pow(max(dot(R, normalize(vec3(0.70, 0.30, -0.62))), 0.0), 22.0) * 0.9;
      col += uSpec * pow(1.0 - ndv, 3.2) * 0.5;
      col *= groove;
      col += uSpec * tick * 1.25;

      gl_FragColor = vec4(col, uAlpha);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }`;

  const metalUniforms = [];
  function metal(o) {
    o = o || {};
    const u = {
      uEnv:  { value: ENV },
      uBase: { value: new THREE.Color(o.base || 0x2b2440) },
      uSpec: { value: new THREE.Color(o.spec || 0xd7c9ff) },
      uKnurl:{ value: o.knurl || 0 },
      uTicks:{ value: o.ticks || 0 },
      uRough:{ value: o.rough || 0 },
      uAlpha:{ value: 1 }
    };
    metalUniforms.push(u);
    return new THREE.ShaderMaterial({
      uniforms: u, vertexShader: baseVert, fragmentShader: metalFrag,
      transparent: true, depthWrite: true,
      side: o.side || THREE.FrontSide
    });
  }

  const D = THREE.DoubleSide;
  const matBody  = metal({ side: D });
  const matRim   = metal({ base: 0x362c52, spec: 0xe4d8ff, side: D });
  const matKnurl = metal({ base: 0x241e38, knurl: 46, rough: 0.25, side: D });
  const matBlade = metal({ base: 0x1d1830, spec: 0xd6c6ff, rough: 0.30, side: D });
  const matScale = metal({ base: 0x241d3a, spec: 0xe6dcff, ticks: 60, rough: 0.30, side: D });
  const matDark  = metal({ base: 0x0c0a15, spec: 0x6c5ba8, rough: 0.92, side: D });
  let markRef = null;

  /* --- стеклянные элементы в оправах --- */
  const ELEMENTS = [
    { R: 0.84, curve: 0.22, edge: 0.09, z: -1.92, ior: 1.44, disp: 0.030, coat: 0.62,
      tint: 0xe4dcff, edge_: 0x7d5cff, abs: [0.34, 0.46, 0.14] },
    { R: 1.00, curve: 0.31, edge: 0.11, z: -0.30, ior: 1.53, disp: 0.046, coat: 0.18,
      tint: 0xfaf7ff, edge_: 0x9a7cff, abs: [0.18, 0.26, 0.12] },
    { R: 0.86, curve: 0.24, edge: 0.10, z:  1.62, ior: 1.47, disp: 0.034, coat: 0.86,
      tint: 0xdcf3ff, edge_: 0x4fd8ff, abs: [0.40, 0.20, 0.10] }
  ];

  ELEMENTS.forEach(el => {
    const g = new THREE.LatheGeometry(lensProfile(el.R, el.curve, el.edge), 128);
    const m = new THREE.Mesh(g, glass({
      tint: el.tint, edge: el.edge_, ior: el.ior, disp: el.disp, abs: el.abs, coat: el.coat
    }));
    m.rotation.x = Math.PI / 2;                 // ось линзы смотрит вдоль Z
    m.position.z = el.z;
    optic.add(m);

    const rim = new THREE.Mesh(
      new THREE.LatheGeometry(ringProfile(el.R + 0.010, el.R + 0.085, 0.11), 96), matRim
    );
    rim.rotation.x = Math.PI / 2;
    rim.position.z = el.z + 0.055;
    optic.add(rim);
  });

  /* --- диафрагма: девять лепестков ---
     Каждый лепесток ограничен хордой (она и рисует просвет) и дугой корпуса,
     поэтому за габарит оправы он не выходит ни при каком раскрытии.
     Просвет меняется сдвигом лепестка к оси, весь набор при этом
     медленно проворачивается — так ведёт себя настоящий механизм. */
  const IRIS_N = 9, IRIS_Z = 2.14, IRIS_OUT = 1.00, IRIS_A = 0.60;
  const blades = [];
  {
    const w = Math.tan(Math.PI / IRIS_N) * IRIS_A * 2.6;
    const shape = new THREE.Shape();
    const a1 = Math.atan2(IRIS_A, w), a0 = Math.atan2(IRIS_A, -w);
    shape.moveTo(-w, IRIS_A);
    shape.lineTo(w, IRIS_A);
    shape.lineTo(Math.cos(a1) * IRIS_OUT, Math.sin(a1) * IRIS_OUT);
    shape.absarc(0, 0, IRIS_OUT, a1, a0, false);
    shape.lineTo(-w, IRIS_A);
    // фаска по кромке лепестка: тонкая светлая линия по краю просвета
    const geo = new THREE.ExtrudeGeometry(shape, {
      depth: 0.011, curveSegments: 28,
      bevelEnabled: true, bevelThickness: 0.004, bevelSize: 0.006, bevelSegments: 1
    });
    for (let i = 0; i < IRIS_N; i++) {
      const th = (i / IRIS_N) * Math.PI * 2;
      const b = new THREE.Mesh(geo, matBlade);
      b.userData.th = th;
      b.userData.z = IRIS_Z + i * 0.0040;
      b.rotation.order = 'ZXY';           // сначала наклон, потом разворот по кругу
      b.rotation.x = 0.11;
      b.rotation.z = th;
      b.position.set(0, 0, b.userData.z);
      optic.add(b);
      blades.push(b);
    }
    // пластина-обойма закрывает стык лепестков с корпусом
    const plate = new THREE.Mesh(
      new THREE.LatheGeometry(ringProfile(0.96, 1.08, 0.11), 96), matBody
    );
    plate.rotation.x = Math.PI / 2;
    plate.position.z = IRIS_Z - 0.05;
    optic.add(plate);
  }

  /* --- корпус ---
     Силуэт собран ступенями: узкий хвостовик, тело, кольцо фокуса,
     кольцо со шкалой и раструб спереди. Обечайки открытые, между ними
     видно стекло, поэтому прибор не превращается в глухую трубу. */
  {
    const shell = (ri, ro, z0, z1, mat, seg) => {
      const m = new THREE.Mesh(
        new THREE.LatheGeometry(shellProfile(ri, ro, z0, z1), seg || 128), mat || matBody
      );
      m.rotation.x = Math.PI / 2;
      optic.add(m);
      return m;
    };

    shell(0.66, 0.82, -3.00, -2.34);     // хвостовик с байонетом
    shell(1.02, 1.14, -1.52,  0.48);     // тело
    shell(1.10, 1.26,  1.24,  2.30);     // раструб

    // накатка: заднее кольцо у хвостовика и большое кольцо фокуса
    const knurlRing = (r, h, z, mat) => {
      const m = new THREE.Mesh(
        new THREE.CylinderGeometry(r, r, h, 160, 1, true), mat
      );
      m.rotation.x = Math.PI / 2;
      m.position.z = z;
      optic.add(m);
      [-h / 2, h / 2].forEach(dz => {
        const e = new THREE.Mesh(new THREE.TorusGeometry(r + 0.012, 0.024, 8, 128), matRim);
        e.position.z = z + dz;
        optic.add(e);
      });
    };
    knurlRing(0.94, 0.34, -1.94, metal({ base: 0x1e1830, knurl: 44, rough: 0.30, side: D }));
    knurlRing(1.20, 0.50, -0.30, matKnurl);

    // кольцо со шкалой
    const scale = new THREE.Mesh(
      new THREE.LatheGeometry(ringProfile(1.14, 1.24, 0.16), 160), matScale
    );
    scale.rotation.x = Math.PI / 2;
    scale.position.z = 0.66;
    optic.add(scale);

    // рёбра: связывают ступени и держат силуэт открытым
    const rods = (radius, len, z, n, phase) => {
      const g = new THREE.CylinderGeometry(0.030, 0.030, len, 8);
      for (let i = 0; i < n; i++) {
        const th = (i / n) * Math.PI * 2 + phase;
        const r = new THREE.Mesh(g, matBody);
        r.rotation.x = Math.PI / 2;
        r.position.set(Math.cos(th) * radius, Math.sin(th) * radius, z);
        optic.add(r);
      }
    };
    rods(0.88, 1.30, -1.98, 6, 0.26);
    rods(1.10, 0.90,  0.86, 6, 0.52);

    // внутренние бленды: гасят паразитный свет и дают глубину при взгляде внутрь
    [-1.10, 0.24, 1.10].forEach(z => {
      const baffle = new THREE.Mesh(
        new THREE.LatheGeometry(ringProfile(0.56, 1.02, 0.03), 72), matDark
      );
      baffle.rotation.x = Math.PI / 2;
      baffle.position.z = z;
      optic.add(baffle);
    });

    // канавка под светофильтр в раструбе
    const groove = new THREE.Mesh(new THREE.TorusGeometry(1.235, 0.020, 8, 128), matDark);
    groove.position.z = 2.16;
    optic.add(groove);

    // метка индекса: единственное тёплое пятно на приборе
    const mark = new THREE.Mesh(
      new THREE.SphereGeometry(0.038, 12, 10),
      new THREE.MeshBasicMaterial({ color: 0xffd7a0, transparent: true })
    );
    mark.position.set(0, 1.26, 0.66);
    optic.add(mark);
    markRef = mark;

    // байонет сзади
    const tab = new THREE.BoxGeometry(0.26, 0.08, 0.09);
    for (let i = 0; i < 3; i++) {
      const th = (i / 3) * Math.PI * 2 + 0.5;
      const t = new THREE.Mesh(tab, matRim);
      t.position.set(Math.cos(th) * 0.74, Math.sin(th) * 0.74, -3.06);
      t.rotation.z = th;
      optic.add(t);
    }
  }

  /* --- точка фокуса: мягкое свечение там, где поток собирается --- */
  const flare = new THREE.Mesh(
    new THREE.PlaneGeometry(1.9, 1.9),
    new THREE.ShaderMaterial({
      uniforms: { uC: { value: new THREE.Color(0xbfe9ff) }, uA: { value: 1 } },
      transparent: true, depthWrite: false, depthTest: false,
      blending: THREE.AdditiveBlending,
      vertexShader: `varying vec2 vUv;
        void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
      fragmentShader: `varying vec2 vUv; uniform vec3 uC; uniform float uA;
        void main(){
          float d = length(vUv - 0.5) * 2.0;
          float a = pow(max(0.0, 1.0 - d), 3.4) * 0.55 + pow(max(0.0, 1.0 - d), 14.0) * 0.9;
          gl_FragColor = vec4(uC, a * uA);
          #include <colorspace_fragment>
        }`
    })
  );
  flare.position.z = 2.35;
  flare.frustumCulled = false;
  rig.add(flare);

  /* --- мягкая тень-подложка ---
     Прибор без неё висит в пустоте. Тёмное пятно за ним слегка гасит фон,
     объект отделяется от страницы и получает вес. */
  const halo = new THREE.Mesh(
    new THREE.PlaneGeometry(9, 9),
    new THREE.ShaderMaterial({
      uniforms: { uA: { value: 1 } },
      transparent: true, depthWrite: false, depthTest: false,
      vertexShader: `varying vec2 vUv;
        void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
      fragmentShader: `varying vec2 vUv; uniform float uA;
        void main(){
          float d = length(vUv - 0.5) * 2.0;
          float a = pow(max(0.0, 1.0 - d), 2.2);
          gl_FragColor = vec4(0.020, 0.015, 0.045, a * uA);
        }`
    })
  );
  halo.position.z = -1.2;
  halo.renderOrder = -1;
  halo.frustumCulled = false;
  rig.add(halo);


  /* ─────────── 3. поток: шум слева, собранный сигнал справа ─────────── */
  const P_COUNT = coarse ? 1800 : 5200;
  const pGeo = new THREE.BufferGeometry();
  {
    const pos = new Float32Array(P_COUNT * 3);            // не используется, но нужен атрибут
    const seed = new Float32Array(P_COUNT);
    const ang  = new Float32Array(P_COUNT);
    const rad  = new Float32Array(P_COUNT);
    const off  = new Float32Array(P_COUNT);
    const sz   = new Float32Array(P_COUNT);
    const bok  = new Float32Array(P_COUNT);   // расфокусированные кружки
    for (let i = 0; i < P_COUNT; i++) {
      bok[i] = Math.random() < 0.026 ? 1 : 0;
      seed[i] = Math.random();
      ang[i]  = Math.random() * Math.PI * 2;
      rad[i]  = 0.12 + Math.pow(Math.random(), 0.74) * 1.30;
      off[i]  = Math.random();
      // мелкой пыли много, крупных искр мало: так поток выглядит шелковистым
      sz[i]   = 0.34 + Math.pow(Math.random(), 2.4) * 1.75;
    }
    pGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    pGeo.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
    pGeo.setAttribute('aAng',  new THREE.BufferAttribute(ang, 1));
    pGeo.setAttribute('aRad',  new THREE.BufferAttribute(rad, 1));
    pGeo.setAttribute('aOff',  new THREE.BufferAttribute(off, 1));
    pGeo.setAttribute('aSz',   new THREE.BufferAttribute(sz, 1));
    pGeo.setAttribute('aBok',  new THREE.BufferAttribute(bok, 1));
    pGeo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 24);
  }

  const pUni = {
    uT:      { value: 0 },
    uSpread: { value: 1 },
    uBright: { value: 1 },
    uScale:  { value: 1 },
    uPx:     { value: 1 }
  };

  const stream = new THREE.Points(pGeo, new THREE.ShaderMaterial({
    uniforms: pUni,
    transparent: true, depthWrite: false, depthTest: false,
    blending: THREE.AdditiveBlending,
    vertexShader: `
      attribute float aSeed, aAng, aRad, aOff, aSz, aBok;
      uniform float uT, uSpread, uBright, uScale, uPx;
      varying float vA; varying vec3 vC; varying float vB;

      void main(){
        float sp = 0.55 + aSeed * 0.85;
        float t  = fract(aOff + uT * 0.030 * sp);
        float z  = mix(-7.0, 6.0, t);
        float zf = 2.35;                                  // фокус

        float order = smoothstep(zf - 0.7, zf + 0.9, z);   // 0 до фокуса, 1 после

        float before = aRad * uSpread * (0.78 + 0.52 * (-z) / 7.0);
        /* После фокуса разлёт у всех почти одинаковый: если оставить его
           пропорциональным личному радиусу, вместо шести лучей получается
           веер. Небольшой разброс по aSeed нужен только чтобы луч не был
           линией в один пиксель. */
        float after  = aRad * uSpread * pow(max(0.0, 1.0 - z / zf), 1.5) + 0.030 * aRad
                     + (0.34 + 0.15 * aSeed) * max(0.0, z - zf);
        float r = mix(before, after, step(0.0, z));

        /* Закрутка ограничена по величине: раньше в ней был линейный член
           от времени, он уводил угол сколь угодно далеко. Из-за этого номер
           ближайшего луча со временем менялся, и частицы перескакивали
           с луча на луч — поток на выходе «сыпался». */
        float a = aAng + z * 0.085 + sin(uT * 0.11 + aSeed * 6.283) * 0.55;

        /* Луч выбирается от собственного угла частицы, а не от плывущего:
           за частицей закреплено одно направление на всё время жизни,
           и она приходит в него плавно, без скачков. */
        float step6 = 6.2831853 / 6.0;
        float aRay = floor(aAng / step6 + 0.5) * step6;
        a = mix(a, aRay, order);

        vec3 pos = vec3(cos(a) * r, sin(a) * r * 0.88, z);

        // турбулентность живёт только слева от прибора и там она сильная
        float noiseZone = smoothstep(0.6, -4.5, z);
        pos.xy += vec2(sin(uT * 0.27 + aSeed * 31.0) + sin(uT * 0.61 + aSeed * 77.0) * 0.45,
                       cos(uT * 0.23 + aSeed * 19.0) + cos(uT * 0.53 + aSeed * 59.0) * 0.45)
                  * 0.30 * noiseZone;

        float k  = smoothstep(-2.6, 2.0, z);
        vec3 col = mix(vec3(0.30, 0.25, 0.58), vec3(0.78, 0.95, 1.0), k);
        col = mix(col, vec3(1.0, 0.60, 0.90), smoothstep(2.6, 5.2, z) * 0.75);
        vC = col;

        float focus = exp(-pow((z - zf) * 1.35, 2.0));
        /* Вход и выход растянуты: частица разгорается на дальнем краю кадра
           и гаснет уже за его пределами, поэтому нигде не видно, как она
           появляется или пропадает. */
        float fade  = smoothstep(0.0, 0.22, t) * (1.0 - smoothstep(0.84, 1.0, t));
        // мягкое мерцание: у каждой частицы своя фаза, разброс небольшой
        float tw = 0.80 + 0.20 * sin(uT * 0.9 + aSeed * 84.0);
        vA = fade * (0.030 + 0.070 * aSeed) * (1.0 + 4.4 * focus) * uBright * tw
             * (1.0 + 0.9 * order)      // упорядоченные лучи держат яркость
             * (1.0 + 0.8 * noiseZone); // и шум на входе виден, иначе истории нет

        vec4 mv = modelViewMatrix * vec4(pos, 1.0);
        // дальняя пыль тусклее ближней — это и даёт ощущение глубины потока
        vA *= mix(0.35, 1.0, clamp((14.0 + mv.z) / 12.0, 0.0, 1.0));

        /* Боке. Небольшая часть пыли живёт как расфокусированные кружки:
           чем дальше частица от точки фокуса, тем крупнее и мягче её диск.
           Ровно так ведёт себя настоящая оптика, и именно это читается
           как «снято объективом», а не «нарисованы точки». */
        float blur = smoothstep(0.25, 3.2, abs(z - zf));
        vB = aBok * blur;
        float size = aSz * uScale * uPx * (1.0 + 0.8 * focus) * (34.0 / max(1.2, -mv.z));
        gl_PointSize = mix(min(size, 22.0 * uPx),
                           min(size * (2.2 + 3.0 * blur), 32.0 * uPx), vB);
        vA = mix(vA, vA * 0.24, vB);
        gl_Position  = projectionMatrix * mv;
      }`,
    fragmentShader: `
      varying float vA; varying vec3 vC; varying float vB;
      void main(){
        float d = length(gl_PointCoord - 0.5) * 2.0;
        // мягкое ядро плюс ореол: точка перестаёт быть «кружком»
        float dot_ = pow(max(0.0, 1.0 - d), 2.2) * 0.75 + pow(max(0.0, 1.0 - d), 8.0) * 0.55;
        // у боке ровная заливка и чуть более яркая кромка — как у реального кружка нерезкости
        float bok = smoothstep(1.0, 0.88, d) * (0.42 + 0.58 * smoothstep(0.62, 0.97, d));
        float a = mix(dot_, bok, vB);
        gl_FragColor = vec4(vC, a * vA);
        #include <colorspace_fragment>
      }`
  }));
  stream.frustumCulled = false;
  stream.renderOrder = 1;
  rig.add(stream);

  /* ─────────── 4. звёзды: очень редкие, только атмосфера ─────────── */
  const S_COUNT = coarse ? 220 : 430;
  const sGeo = new THREE.BufferGeometry();
  {
    const p = new Float32Array(S_COUNT * 3), s = new Float32Array(S_COUNT);
    for (let i = 0; i < S_COUNT; i++) {
      const th = Math.random() * Math.PI * 2, ph = Math.acos(2 * Math.random() - 1);
      const R = 26 + Math.random() * 22;
      p[i * 3]     = Math.sin(ph) * Math.cos(th) * R;
      p[i * 3 + 1] = Math.cos(ph) * R * 0.7;
      p[i * 3 + 2] = Math.sin(ph) * Math.sin(th) * R - 8;
      s[i] = 0.5 + Math.random() * 1.6;
    }
    sGeo.setAttribute('position', new THREE.BufferAttribute(p, 3));
    sGeo.setAttribute('aSz', new THREE.BufferAttribute(s, 1));
  }
  const stUni = { uT: { value: 0 }, uPx: { value: 1 }, uA: { value: 1 } };
  const stars = new THREE.Points(sGeo, new THREE.ShaderMaterial({
    uniforms: stUni, transparent: true, depthWrite: false,
    blending: THREE.AdditiveBlending,
    vertexShader: `
      attribute float aSz; uniform float uT, uPx; varying float vTw;
      void main(){
        vTw = 0.55 + 0.45 * sin(uT * 0.55 + aSz * 42.0);
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = aSz * uPx * (80.0 / max(1.0, -mv.z));
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: `
      uniform float uA; varying float vTw;
      void main(){
        float d = length(gl_PointCoord - 0.5);
        float a = smoothstep(0.5, 0.05, d);
        gl_FragColor = vec4(vec3(0.82, 0.80, 1.0), a * vTw * 0.42 * uA);
        #include <colorspace_fragment>
      }`
  }));
  stars.frustumCulled = false;
  scene.add(stars);

  /* ─────────── 5. хореография по прокрутке ───────────
     Ключевые кадры расставлены по доле прокрутки страницы. Между ними
     плавная интерполяция, поэтому объектив живёт непрерывно и нигде
     не перепрыгивает. */
  /* Каждый кадр привязан к своей секции страницы. Поле e — сглаживание
     отрезка, который с этого кадра начинается: 'soft' мягко трогается
     и мягко тормозит, 'in' разгоняется (для влёта), 'out' тормозит
     (для выхода), 'smooth' — ровный ход по умолчанию. */
  const KEYS = [
    /* первый экран: прибор целиком, три четверти спереди-справа */
    { t: 0.000, sec: 'hero', p: 0.5000, cz: 7.2, cy:  0.00, x:  1.62, y: -0.04, z: -0.2, rx: -0.20, ry:  0.88, s: 0.46, sp: 1.00, br: 1.00, op: 1.00, ro:  0.000 },
    /* о нас: разворачивается боком, отходит к правому полю */
    { t: 0.106, sec: 'about', p: 0.6210, cz: 7.5, cy:  0.08, x:  3.05, y: -0.30, z: -0.8, rx: -0.09, ry:  1.30, s: 0.38, sp: 1.15, br: 0.55, op: 0.56, ro:  0.014 },
    /* цифры: поднимается над полосой чисел, становится мелким и тихим */
    { t: 0.165, sec: 'figures', p: 0.5287, cz: 7.8, cy: -0.06, x:  3.55, y:  0.46, z: -1.6, rx: -0.22, ry:  1.62, s: 0.30, sp: 1.25, br: 0.42, op: 0.40, ro: -0.010 },
    /* с кем работаем: поворачивается к зрителю передом, начинается сближение */
    { t: 0.226, sec: 'audience', p: 0.3684, cz: 6.6, cy: -0.02, x:  3.30, y: -0.08, z:  0.2, rx:  0.06, ry:  0.72, s: 0.36, sp: 1.30, br: 0.46, op: 0.42, ro:  0.016 },
    /* Услуги: макро на кольце фокуса у правого края, видно накатку и шкалу.
       Секция закреплена под колоду и занимает около 40% всей прокрутки, поэтому
       кадров здесь три, а не один: с одним прибор на все пять экранов листания
       практически замирал. Кольцо медленно проворачивается, пока идут карточки. */
    /* Средний кадр — исходная поза, она уже была принята заказчиком. Крайние
       только доворачивают прибор вокруг неё: размер и яркость держатся на том
       же уровне, потому что справа лежит список услуг, а секция теперь идёт
       пять экранов, и любой прирост тут же съедает его строки. */
    { t: 0.300, sec: 'services', p: 0.1200, cz: 5.2, cy:  0.00, x:  2.98, y:  0.06, z:  1.2, rx: -0.12, ry:  0.56, s: 0.68, sp: 1.30, br: 0.44, op: 0.25, ro:  0.020 },
    { t: 0.332, sec: 'services', p: 0.4032, cz: 5.0, cy:  0.00, x:  2.95, y:  0.10, z:  1.4, rx: -0.10, ry:  0.44, s: 0.72, sp: 1.30, br: 0.46, op: 0.26, ro:  0.026 },
    { t: 0.380, sec: 'services', p: 0.7300, cz: 5.0, cy:  0.02, x:  3.02, y:  0.14, z:  1.5, rx: -0.08, ry:  0.32, s: 0.72, sp: 1.30, br: 0.46, op: 0.26, ro:  0.032 },
    /* клиенты: отходит к правому полю и затихает — стена имён должна читаться */
    { t: 0.436, sec: 'clients', p: 0.5570, cz: 5.6, cy:  0.02, x:  3.30, y:  0.26, z:  0.3, rx: -0.12, ry:  0.62, s: 0.40, sp: 1.30, br: 0.36, op: 0.22, ro:  0.012 },
    /* граница клиентов и кейсов: разгон к диафрагме, она растёт в кадре */
    { t: 0.482, sec: 'cases', p: 0.1058, cz: 4.8, cy:  0.00, x:  1.00, y:  0.00, z:  2.35, rx: -0.02, ry:  0.16, s: 0.80, sp: 1.10, br: 0.58, op: 0.26, ro:  0.048 },
    /* кейсы: мы внутри тубуса, кольца оправ идут тоннелем по краям кадра */
    { t: 0.548, sec: 'cases', p: 0.6200, cz: 4.0, cy:  0.00, x:  0.00, y:  0.00, z:  1.55, rx:  0.02, ry:  0.02, s: 1.32, sp: 1.00, br: 0.30, op: 0.32, ro: -0.058 },
    /* фаундер: вышли с обратной стороны, прибор за левым полем */
    { t: 0.647, sec: 'founder', p: 0.3825, cz: 6.2, cy:  0.06, x: -3.95, y:  0.34, z: -1.6, rx:  0.24, ry: -1.35, s: 0.40, sp: 1.50, br: 0.30, op: 0.30, ro:  0.020 },
    /* команда: уходит далеко, медленно разворачивается обратно */
    { t: 0.777, sec: 'team', p: 0.5259, cz: 7.6, cy:  0.00, x: -3.55, y: -0.36, z: -3.6, rx: -0.34, ry: -2.40, s: 0.30, sp: 1.70, br: 0.24, op: 0.26, ro:  0.000 },
    /* партнёры: ныряет вниз за кадр */
    { t: 0.855, sec: 'partners', p: 0.4740, cz: 7.6, cy:  0.00, x: -1.20, y: -3.70, z: -4.0, rx: -0.50, ry: -3.10, s: 0.32, sp: 1.50, br: 0.18, op: 0.08, ro:  0.000 },
    /* форма: возвращается за стеклянную панель, передом к зрителю */
    { t: 0.930, sec: 'contact', p: 0.4087, cz: 6.8, cy:  0.00, x:  1.72, y: -0.10, z: -0.4, rx: -0.16, ry: -0.34, s: 0.45, sp: 0.90, br: 0.95, op: 0.86, ro:  0.000 },
    /* подвал: уходит вверх */
    { t: 1.000, sec: 'footer', p: 0.2321, cz: 7.6, cy:  0.24, x:  0.62, y:  1.05, z: -2.6, rx: -0.26, ry: -0.18, s: 0.34, sp: 1.00, br: 0.58, op: 0.40, ro:  0.000 }
  ];
  const FIELDS = ['cz', 'cy', 'x', 'y', 'z', 'rx', 'ry', 's', 'sp', 'br', 'op', 'ro'];

  /* Монотонный кубический сплайн (PCHIP) вместо покадрового сглаживания.
     Кусочные кривые давали разрыв скорости на стыках: отрезок заканчивался
     разгоном, а следующий начинался с нуля, и в этом месте движение
     спотыкалось. Сплайн непрерывен по скорости во всех кадрах сразу,
     а монотонность гарантирует, что кривая не выскочит за значения
     соседних кадров (важно для прозрачности и масштаба). */
  /* Поле t — доля ОБЩЕЙ прокрутки, и она едет, стоит любой секции изменить
     высоту (закреплённая колода услуг добавляет несколько экранов). Поэтому
     каждый кадр дополнительно привязан к своей секции: sec — её id, p — доля
     высоты секции, на которой кадр стоит. Значения sec/p сняты с исходной
     вёрстки, так что картинка осталась ровно та же, но теперь она держится
     за секции, а не за суммарную длину страницы. */
  function resolveKeys() {
    const max = document.documentElement.scrollHeight - innerHeight;
    if (max <= 0) return;
    let prev = 0;
    for (let i = 0; i < KEYS.length; i++) {
      const k = KEYS[i];
      const el = document.getElementById(k.sec)
              || (k.sec === 'footer' ? document.querySelector('footer') : null);
      if (!el) continue;
      let top = 0;
      for (let nd = el; nd; nd = nd.offsetParent) top += nd.offsetTop;
      let t = (top + k.p * el.offsetHeight - innerHeight / 2) / max;
      if (i === 0) t = 0;
      else if (i === KEYS.length - 1) t = 1;
      // кадры обязаны идти строго по возрастанию, иначе сплайн разваливается
      k.t = Math.min(1, Math.max(i === 0 ? 0 : prev + 1e-4, t));
      prev = k.t;
    }
    buildSlopes();
  }

  const SLOPE = {};
  function buildSlopes() {
    const n = KEYS.length;
    for (const f of FIELDS) {
      const d = new Array(n - 1), m = new Array(n);
      for (let i = 0; i < n - 1; i++) d[i] = (KEYS[i + 1][f] - KEYS[i][f]) / (KEYS[i + 1].t - KEYS[i].t);
      m[0] = d[0];
      m[n - 1] = d[n - 2];
      for (let i = 1; i < n - 1; i++) {
        if (d[i - 1] * d[i] <= 0) { m[i] = 0; continue; }
        const h0 = KEYS[i].t - KEYS[i - 1].t, h1 = KEYS[i + 1].t - KEYS[i].t;
        const w1 = 2 * h1 + h0, w2 = h1 + 2 * h0;
        m[i] = (w1 + w2) / (w1 / d[i - 1] + w2 / d[i]);
      }
      SLOPE[f] = m;
    }
  }
  buildSlopes();

  const K = {};
  function sampleKeys(t) {
    let i = 0;
    while (i < KEYS.length - 2 && t > KEYS[i + 1].t) i++;
    const a = KEYS[i], b = KEYS[i + 1], h = b.t - a.t;
    let u = (t - a.t) / h;
    u = Math.min(1, Math.max(0, u));
    const u2 = u * u, u3 = u2 * u;
    const h00 = 2 * u3 - 3 * u2 + 1, h10 = u3 - 2 * u2 + u;
    const h01 = -2 * u3 + 3 * u2,    h11 = u3 - u2;
    for (const f of FIELDS) {
      K[f] = h00 * a[f] + h10 * h * SLOPE[f][i] + h01 * b[f] + h11 * h * SLOPE[f][i + 1];
    }
  }

  /* ─────────── 6. цикл ─────────── */
  let W = 0, H = 0, dpr = 1, xk = 1, yk = 0, sk = 1, ok = 1;
  const pointer = { x: 0, y: 0, tx: 0, ty: 0 };
  const cur = { x: 0, y: 0, z: 0, rx: 0, ry: 0, s: 1, cz: 7.2, cy: 0, ro: 0 };
  let scrollT = 0, scrollS = 0, scrollPrev = 0, scrollV = 0, started = false;
  let tuneAcc = 0, tuneN = 0;

  /* Критически задемпфированная пружина: доводит значение до цели без перелёта
     и без рывков, независимо от частоты кадров. smooth — время «доводки» в секундах. */
  const vel = {};
  function damp(current, target, key, smooth, dt) {
    const omega = 2 / smooth;
    const x = omega * dt;
    const exp = 1 / (1 + x + 0.48 * x * x + 0.235 * x * x * x);
    const change = current - target;
    const v = vel[key] || 0;
    const temp = (v + omega * change) * dt;
    vel[key] = (v - omega * temp) * exp;
    return target + (change + temp) * exp;
  }

  function applyDpr() {
    dpr = Math.min(devicePixelRatio || 1, dprCap);
    renderer.setPixelRatio(dpr);
    renderer.setSize(W, H, false);
    pUni.uPx.value = dpr * (coarse ? 0.85 : 1);
    stUni.uPx.value = dpr;
  }

  function resize() {
    W = innerWidth; H = innerHeight;
    applyDpr();
    camera.aspect = W / H;
    camera.fov = W / H < 0.85 ? 44 : 34;         // на вертикальных экранах шире
    camera.updateProjectionMatrix();
    xk = Math.min(1, Math.max(0.24, (W / H) / 1.65));
    // на вертикальных экранах прибор уходит ниже текста и уменьшается
    const portrait = W / H < 0.85;
    yk = portrait ? -1.78 : 0;
    sk = portrait ? 0.64 : 1;
    ok = portrait ? 0.78 : 1;
  }

  function readScroll() {
    const max = document.documentElement.scrollHeight - innerHeight;
    scrollT = max > 0 ? Math.min(1, Math.max(0, scrollY / max)) : 0;
  }

  addEventListener('resize', () => { resize(); resolveKeys(); readScroll(); }, { passive: true });
  addEventListener('scroll', readScroll, { passive: true });
  /* Колода услуг задаёт свою высоту уже после разбора вёрстки, поэтому она
     дёргает пересчёт сама — иначе кадры считались бы по старой длине. */
  window.__vakRelayout = () => { resolveKeys(); readScroll(); };
  if (!coarse) addEventListener('pointermove', e => {
    pointer.tx = (e.clientX / innerWidth - 0.5) * 2;
    pointer.ty = (e.clientY / innerHeight - 0.5) * 2;
  }, { passive: true });

  resize(); resolveKeys(); readScroll();

  const clock = new THREE.Clock();
  let time = 0, paused = false;
  document.addEventListener('visibilitychange', () => { paused = document.hidden; });

  function frame() {
    requestAnimationFrame(frame);
    if (paused) return;
    step();
  }
  function step(dtForce) {
    const dt = dtForce !== undefined ? dtForce : Math.min(0.05, clock.getDelta());
    if (!reduced) time += dt;

    /* Автоподстройка разрешения. Раз в полсекунды смотрим на средний шаг
       кадра: не укладываемся в бюджет — снижаем плотность пикселей, есть
       запас — возвращаем. Дешевле любого другого рычага, потому что цена
       кадра здесь почти целиком заливка. */
    if (dtForce === undefined) {
      tuneAcc += dt; tuneN++;
      if (tuneN >= 30) {
        const avg = tuneAcc / tuneN;
        tuneAcc = 0; tuneN = 0;
        if (avg > 0.0225 && dprCap > DPR_MIN) {
          dprCap = Math.max(DPR_MIN, dprCap - 0.15); applyDpr();
        } else if (avg < 0.0140 && dprCap < DPR_MAX) {
          dprCap = Math.min(DPR_MAX, dprCap + 0.10); applyDpr();
        }
      }
    }

    /* Сглаживается не каждое значение по отдельности, а сама позиция на пути:
       пружина без перелёта тянет scrollS к реальной прокрутке, а дальше прибор
       строго идёт по заданной траектории. Из-за этого движение не «плывёт»
       мимо ключевых кадров при быстром скролле и остаётся мягким. */
    scrollS = reduced ? scrollT : damp(scrollS, scrollT, 'st', 0.34, dt);
    sampleKeys(scrollS);

    /* Скорость и направление прокрутки. Прибор на них реагирует: кренится
       в сторону движения, слегка поджимает диафрагму и разгоняет поток.
       Работает одинаково вниз и вверх, только знак крена меняется. */
    const rawV = (scrollS - scrollPrev) / Math.max(dt, 1e-4);
    scrollPrev = scrollS;
    scrollV += (rawV - scrollV) * Math.min(1, dt * 7);
    const vv = Math.max(-1, Math.min(1, scrollV * 1.7));
    const va = Math.abs(vv);

    pointer.x += (pointer.tx - pointer.x) * Math.min(1, dt * 2.6);
    pointer.y += (pointer.ty - pointer.y) * Math.min(1, dt * 2.6);

    cur.x  = K.x * xk;
    cur.y  = K.y + yk;
    cur.z  = K.z;
    cur.s  = K.s * sk;
    cur.cz = K.cz;
    cur.cy = K.cy;
    cur.ro = K.ro;
    // поворот догоняет чуть мягче остального: так прибор «доводится» на месте
    cur.rx = reduced ? K.rx : damp(cur.rx, K.rx, 'rx', 0.22, dt);
    cur.ry = reduced ? K.ry : damp(cur.ry, K.ry, 'ry', 0.26, dt);

    const breathe = reduced ? 0 : Math.sin(time * 0.42) * 0.055;

    rig.position.set(cur.x, cur.y + breathe, cur.z);
    rig.rotation.set(
      cur.rx + pointer.y * 0.10 - vv * 0.05,
      cur.ry + time * 0.012 + pointer.x * 0.16,   // очень медленный собственный поворот
      Math.sin(time * 0.24) * 0.03 + vv * 0.06    // крен в сторону прокрутки
    );
    rig.scale.setScalar(cur.s);

    // диафрагма дышит и подбирается на быстрой прокрутке, как при съёмке в проводке
    const shut = reduced ? 0.10
      : (Math.sin(time * 0.17) * 0.5 + 0.5) * 0.22 + va * 0.14;
    const spin = reduced ? 0 : shut * 0.42;
    for (let i = 0; i < blades.length; i++) {
      const b = blades[i], th = b.userData.th + spin;
      b.rotation.z = th;
      b.rotation.x = 0.11;
      b.position.set(Math.sin(th) * shut, -Math.cos(th) * shut, b.userData.z);
    }

    camera.position.set(pointer.x * 0.16, cur.cy + pointer.y * -0.10, cur.cz);
    camera.lookAt(0, 0, 0);
    camera.rotateZ(cur.ro - vv * 0.026);        // крен на пролёте и по скорости
    flare.quaternion.copy(camera.quaternion);   // блик всегда лицом к камере
    halo.quaternion.copy(camera.quaternion);

    pUni.uT.value = time;
    stUni.uT.value = time;
    pUni.uSpread.value = K.sp * (1 + va * 0.10);       // поток чуть шире на разгоне
    pUni.uBright.value = K.br * ok * (1 + va * 0.30);  // и заметно ярче
    pUni.uScale.value  = 0.85 + K.s * 0.45;
    stUni.uA.value = 0.35 + (1 - scrollS) * 0.65;

    const op = K.op * ok;
    for (const u of glassUniforms) { u.uAlpha.value = op; u.uGain.value = 0.85 + op * 0.40; }
    for (const u of metalUniforms) u.uAlpha.value = op * 0.92;
    if (markRef) markRef.material.opacity = op;
    flare.material.uniforms.uA.value = K.br * ok * 0.34;
    halo.material.uniforms.uA.value = op * 0.85;

    renderer.render(scene, camera);

    if (!started) { started = true; canvas.classList.add('is-ready'); }
  }


  frame();
}
